from kivymd.app import MDApp
from kivymd.uix.tab import MDTabsBase
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.button import ButtonBehavior
from kivymd.uix.list import OneLineIconListItem, IconLeftWidget
from kivymd.uix.picker import MDThemePicker, MDTimePicker, MDDatePicker
from kivy.uix.gridlayout import GridLayout
from kivy.uix.scrollview import ScrollView
from kivymd.uix.dialog import MDDialog
from playsound import playsound as p
from datetime import date
from kivymd.toast import toast
import os

from kivy.core.window import Window
Window.size = (320, 600)


class Tab(FloatLayout, MDTabsBase):
    pass


class MyBtn(OneLineIconListItem, ButtonBehavior):
    pass


class MainApp(MDApp):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.theme_cls.primary_palette = 'Purple'

    def build(self):
        for i, j, k in os.walk(r"/sdcard/"):
            for lis in k:
                if lis.endswith(".mp3"):
                    img = IconLeftWidget(icon='music-note')
                    item = MyBtn(text=str(lis))
                    item.bind(on_press=lambda x: p(str(item)))
                    item.add_widget(img)
                    self.root.ids.music_list.add_widget(item)

        for i, j, k in os.walk(r"/sdcard/"):
            for fol in k:
                if fol.endswith('.mp4'):
                    imgs = IconLeftWidget(icon='library-video')
                    items = OneLineIconListItem(text=str(fol))
                    item.bind(on_press=lambda x: p(str(item)))
                    items.add_widget(imgs)
                    self.root.ids.folder.add_widget(items)

    def toastres(self):
        toast("I am Comming Soon...", duration=1.5)

    @staticmethod
    def callback():
        print("it worked..........")

    def toastres2(self):
        toast("No music to play", duration=1.5)

    def change_theme(self):
        theme_dialog = MDThemePicker()
        theme_dialog.open()

    def show_time(self):
        time_dialog = MDTimePicker()
        time_dialog.open()

    def get_date(self, date):
        pass

    def show_date(self):
        date_dialog = MDDatePicker(callback=self.get_date)
        date_dialog.open()

    def about(self):
        pop = MDDialog(
            title="About App",
            text="This is app is still on alpha stage and fully written in python, kivy and KivyMD.",
            size_hint=[.6, .7]
            # pos_hint={'center_x': .5, 'center_y': .5}
        )
        pop.open()

    def message(self):
        pop2 = MDDialog(
            text=f"I LOVE YOU BUT STAY HOME, SAVE YOUR LIFE AND SAVE MY LIFE cheers",
            size_hint=[.6, .9])
        pop2.open()

    def msg(self):
        toast("STAY HOME!!", duration=3)


if __name__ == "__main__":
    MainApp().run()
